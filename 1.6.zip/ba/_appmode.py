# Released under the MIT License. See LICENSE for details.
#
"""Functionality related to the high level state of the app."""
