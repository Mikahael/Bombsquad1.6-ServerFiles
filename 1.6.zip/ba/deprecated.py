# Released under the MIT License. See LICENSE for details.
#
"""Deprecated functionality.

Classes or functions can be relocated here when they are deprecated.
Any code using them should migrate to alternative methods, as
deprecated items will eventually be fully removed.
"""
